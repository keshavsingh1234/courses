-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2021 at 12:01 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paymentgateway_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(222) NOT NULL,
  `name` varchar(222) NOT NULL,
  `coursename` varchar(222) NOT NULL,
  `sellingprice` float NOT NULL,
  `thumbnail` varchar(222) NOT NULL,
  `videopreview` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `name`, `coursename`, `sellingprice`, `thumbnail`, `videopreview`) VALUES
(1, 'sunny', 'english', 3456, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(2, 'keshav', 'coding', 678, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(3, 'oiuy', '34', 4556, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(4, '345', 'qwer', 2345, 'girl-g5ffe27631_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(5, '345', 'qwer', 2345, 'girl-g5ffe27631_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(6, '345', 'qwer', 2345, 'girl-g5ffe27631_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(7, '345', 'qwer', 2345, 'girl-g5ffe27631_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(8, ';lkjh', '56', 345, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(9, ';lkjh', '56', 345, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(10, ';lkjh', '56', 345, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(11, 'oiuyh', 'oiuy', 234, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(12, 'oiuyh', 'oiuy', 234, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(13, 'oiuyh', 'oiuy', 234, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(14, 'oiuyh', 'oiuy', 234, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4'),
(15, 'oiuyh', 'oiuy', 234, 'fantasy-g9aa403876_1920.jpg', 'file_example_MP4_480_1_5MG.mp4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
