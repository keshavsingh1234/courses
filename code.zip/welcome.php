<html>
<head>
 <title></title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
   <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

</head>
<body>
<h1 style="font-weight:bold;">Here are all courses Please Buy</h1> 
<?php
 include 'connnn.php'; 
 $q = "select * from task";
 $query = mysqli_query($con,$q);
  while($res = mysqli_fetch_array($query)){
  $_SESSION['ue']=$res['name'];
  $c=$res['coursename'];
  $sp=$res['sellingprice'];
  $thumb=$res['thumbnail'];
  $video=$res['videopreview'];


 ?>
<div class="container">
  
 <div class="row">
   <div class="col-12">
   
					    <a href="mycode.html" class="btn btn-primary m-1">Add new course</a>
					    <img src="<?php echo $thumb;  ?>" alt="img" class="img-fluid mb-2" >
					    <div class="card-body">
						<h1><?php echo $res['id'];?></h1>
						<h4 class="card-title"><?php  echo $res['name'];  ?></h4>
						<p class="card-text"><?php echo $sp;  ?></p>
					    <h4 class="card-title">course name</h4>
					    <p class="card-text"><?php echo $c;  ?></p>
					    <h4 class="card-title">selling price</h4>
						<h4 class="card-text" style="font-weight:100"> <a href="buy.php?b=<?php echo $res['id'];?>">Rupee <?php echo $sp;?>/- Buy</a> </h4>
						<h4 class="card-title">video preview</h4>
						<video controls poster="/images/w3html5.gif">
				        <source src="<?php echo $video;?>" type="video/mp4">
				        </video>
                       <h1><button class="btn-danger btn card-text"> <a href="cdel.php?com=<?php echo $res['id']; ?>" class="text-white"> Delete </a>  </button> </h1>

    </div>
  </div>
 </div>
</div>
 

<?php 
 }
 ?>
 </body>
</html>