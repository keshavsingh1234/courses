<?php
//we use post method to get data from mycode.html
include 'connnn.php';            //database connectivity file 
				$name=$_POST['name'];            //fetch name with the help of name attribbute ie username="name"
					
				$course=$_POST['cname'];        //fetch course name from mycode.html ie name="cname"
				$sp=$_POST['sp'];               //fetch selling price from name attriute that used in mycode.html
				$thum=$_FILES["thum"];     
				//echo json_encode($video);              //if we print the $video then it return the name index as i shown on screennshot
				$thumb = $thum["name"];        //so store in variable $thumn and insert into db
				$video=$_FILES["video"];       //fetch import video from mycode.html
				//echo json_encode($video);              //if we print the $video then it return the name index as i shown on screennshot

                $videopre = $video["name"];     //so get $video["name"] in variable $videopre and insert into dataase
  

    $q="insert into task(name,coursename,sellingprice,thumbnail,videopreview) values('$name','$course','$sp','$thumb','$videopre')";
    $qu=mysqli_query($con,$q);
	header("location:welcome.php");    //redirect into welcome.php
 

?>